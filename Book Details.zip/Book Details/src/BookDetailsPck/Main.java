package BookDetailsPck;

import java.util.Scanner;

import static BookDetailsPck.Author.retrieveBooksByAuthor;


public class Main {

    // Replace these values with your own database and API credentials
    private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/bookstore";
    private static final String DATABASE_USER = "root";
    private static final String DATABASE_PASSWORD = "password";
    private static final String API_URL = "https://example.com/api";
    private static final String API_KEY = "your_api_key_here";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("Welcome to the Bookstore App!");
            System.out.println("1. Create a book");
            System.out.println("2. Retrieve a book's details");
            System.out.println("3. Create an author");
            System.out.println("4. Retrieve a list of books by author");
            System.out.println("5. Quit\n");
            System.out.print("Enter your choice (1-5): ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    createBook();
                    break;
                case 2:
                    retrieveBookDetailsByIsbn();
                    break;
                case 3:
                    createAuthor();
                    break;
                case 4:
                    retrieveBooksByAuthor();
                    break;
                case 5:
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }

        scanner.close();
    }


    public static void createAuthor()
    {
        String firstName = "";
        String lastName = "";
        String biography = "";
        String publisher = "";

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the first name of the author: ");
        firstName = scanner.nextLine();
        System.out.print("Enter the last name of the author: ");
        lastName = scanner.nextLine();
        System.out.print("Enter the biography: ");
        biography = scanner.nextLine();
        System.out.print("Enter the publisher: ");
        publisher = scanner.next();

        Author newAuthor = new Author(firstName, lastName, biography, publisher);

        System.out.println("You have created new author: " + newAuthor);
    }


    public static void retrieveBookDetailsByIsbn(){}

    public static void createBook() {
        int isbn;
        String name;
        String description;
        double price;
        String author;
        String genre;
        String publisher;
        int yearPublished;
        int copiesSold;
        Scanner scanner = new Scanner(System.in);


        System.out.println("Enter the book ISBN: ");
         isbn = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter the book name: ");
         name = scanner.nextLine();

        System.out.println("Enter the book descrip1tion: ");
         description = scanner.nextLine();

        System.out.println("Enter the book price: ");
         price = scanner.nextDouble();
        scanner.nextLine();
        System.out.println("Enter the book author: ");
         author =  scanner.nextLine();

        System.out.println("Enter the book genre: ");
         genre =  scanner.nextLine();

        System.out.println("Enter the book publisher: ");
         publisher =  scanner.nextLine();

        System.out.println("Enter the year the book was published: ");
         yearPublished = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter the number of copies sold: ");
         copiesSold = scanner.nextInt();
        scanner.nextLine();
        Book newBook = new Book(isbn, name,  description,  price,  author,  genre,  publisher,  yearPublished,  copiesSold);
        System.out.println(newBook);

        // Add the book to the database

    }
}