package BookDetailsPck;

import java.awt.print.Book;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class BookstoreApp {

    // Replace these values with your own database and API credentials
    private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/bookstore";
    private static final String DATABASE_USER = "root";
    private static final String DATABASE_PASSWORD = "password";
    private static final String API_URL = "https://example.com/api";
    private static final String API_KEY = "your_api_key_here";


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("Welcome to the Bookstore App!");
            System.out.println("1. Create a book");
            System.out.println("2. Retrieve a book's details");
            System.out.println("3. Create an author");
            System.out.println("4. Retrieve a list of books by author");
            System.out.println("5. Quit");
            System.out.print("Enter your choice (1-5): ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    createBook();
                    break;
                case 2:
                    retrieveBookDetails();
                    break;
                case 3:
                    createAuthor();
                    break;
                case 4:
                    retrieveBooksByAuthor();
                    break;
                case 5:
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }

        scanner.close();
    }


    private static void retrieveBookDetails() {
    }

    private static void createBook() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the book ISBN: ");
        String isbn = scanner.nextLine();

        System.out.print("Enter the book name: ");
        String name = scanner.nextLine();

        System.out.print("Enter the book description: ");
        String description = scanner.nextLine();

        System.out.print("Enter the book price: ");
        double price = scanner.nextDouble();

        scanner.nextLine(); // Consume the newline character

        System.out.print("Enter the book author: ");
        String author = scanner.nextLine();

        System.out.print("Enter the book genre: ");
        String genre = scanner.nextLine();

        System.out.print("Enter the book publisher: ");
        String publisher = scanner.nextLine();

        System.out.print("Enter the year the book was published: ");
        int yearPublished = scanner.nextInt();

        System.out.print("Enter the number of copies sold: ");
        int copiesSold = scanner.nextInt();

        Book book = new Book(isbn, name, description, price, author, genre, publisher, yearPublished, copiesSold);

        // Add the book to the database

    }
}